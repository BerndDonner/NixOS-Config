{ pkgs
, symbol ? "⚛"
, inputs ? null
, flakeLockPath ? null
, checkInputs ? [ "nixos-config" ]
, message ? "Electron development environment ready"
, nodejsPackage ? pkgs.nodejs_22
, electronPackage ? pkgs.electron
, codePackage ? pkgs.vscode-fhs
, includeElectron ? true
, includeCode ? true
, extraPackages ? [ ]
, extraNativeBuildInputs ? [ ]
, extraBuildInputs ? [ ]
, secretSets ? [ ]
, extraShellHook ? ""
}:

let
  secretHook = import ./secret-shell-hook.nix { inherit pkgs secretSets; };

  lib = pkgs.lib;

  nativeBuildInputs = with pkgs; [
    nodejsPackage
    python3
    pkg-config
    gcc
    gnumake
  ] ++ extraNativeBuildInputs;

  buildInputs = [
    (pkgs.systemd.dev or pkgs.systemd)
    (pkgs.libusb1.dev or pkgs.libusb1)
  ] ++ extraBuildInputs;

  runtimePackages =
    lib.optionals includeElectron [ electronPackage ]
    ++ lib.optionals includeCode [ codePackage ]
    ++ extraPackages ++ [ (import ./devflake-update.nix { inherit pkgs; }) ];

  promptHook = import ./prompt-hook.nix { inherit symbol; };
  updateWarningHook = import ./devshell-update.nix {
    inherit pkgs inputs flakeLockPath checkInputs;
  };
in
pkgs.mkShell {
  name = "electron-development";

  packages = runtimePackages;
  inherit nativeBuildInputs buildInputs;

  LD_LIBRARY_PATH = lib.makeLibraryPath buildInputs;
  NPM_CONFIG_PREFIX = "$HOME/.cache/npm/global";

  # Current node-addon-api headers use C++17 features such as
  # std::string_view and if constexpr.
  CXXFLAGS = "-std=c++17";

  shellHook = ''
    ${secretHook}
    mkdir -p "$NPM_CONFIG_PREFIX/bin"
    export PATH="$NPM_CONFIG_PREFIX/bin:$PATH"

    ${promptHook}
    ${updateWarningHook}

    echo "${message}"
    echo "Node: $(node --version)"
    echo "npm:  $(npm --version)"
    ${lib.optionalString includeCode ''echo "VS Code: $(command -v code)"''}

    ${extraShellHook}
  '';
}
